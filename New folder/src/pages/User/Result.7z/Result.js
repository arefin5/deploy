import React from "react";
import { BaseUrl } from "../../utils/constant";
import axios from "axios";
import { useState, useEffect } from "react";
import Sidebar from "../../Components/Sidebar/Sidebar";
import { useUserContext } from "../../context";
const StudentResult = () => {
    const {user, dispatch} = useUserContext()
  const [students, setStudents] = useState([]);
  const [id,setID]=useState(0)
  useEffect(() => {
    fetchStudents();
  }, [students]);
  const fetchStudents = async () => {
    let ids= await   user.user._id;
    try {
      const { data } = await axios.get(BaseUrl + "/get-all-student");
      setStudents(data);
      setID(ids)
    //   console.log(students);
    } catch (err) {
      console.log(err);
    }
  };
  
  let result=students.filter(student=>{
    if(student.id===id){
      return student
    }else{
      return null
    }
  })

  //  console.log("result",result)
  return (
    <>
      <div className="container-fluid">
        <div className="row">
          <div className="col-lg-3 ps-0">
          </div>
          <div className="col-lg-9 ">
           <div className="row">
               
              {
                     (user  &&  result.length>0 ?
                     
                     (<>
                                 {result.map((student) => {
              return (
                <div key={student._id} className="col-md-3">
                 <div className="card mb-5">
                 <div className="card-body">
                    <h5 className="card-title">Name : {student.name}</h5>
                    <p className="card-text text-dark">Email:{student.studentId.email}</p>
                    <p className="card-text text-dark">Mark:{student.mark}</p>
                 </div>
                 </div>
                </div>
              )
            })}
                     </>):(
                       <>
                       <h1>You Have No result </h1>
                       </>
                     ))
              }



           </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default StudentResult;
